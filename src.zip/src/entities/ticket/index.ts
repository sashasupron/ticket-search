export { Ticket } from './ui/ticket';
// export { ticketReducer, addTicket, removeTicket, clearTickets } from './model/ticketSlice';

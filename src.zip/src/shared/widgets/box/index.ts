export { BoxMainPage } from "./searchPage/ui/boxMainPage";
export { default as BoxTicketPage } from "./ticketPage/ui/boxTicketPage";

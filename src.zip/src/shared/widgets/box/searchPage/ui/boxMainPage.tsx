"use client";
import { Box, Grid2, SxProps } from "@mui/material";
import { Buttons } from "@/shared/ui/buttons/buttons";
import { DatePickers } from "@/shared/ui/pickers/datePicker";
import { Autocompletes } from "@/shared/ui/autocomplete/autocomplete";
import { Selects } from "@/shared/ui/selects/selects";
import styles from './boxMainPage.module.css';
import clsx from "clsx";
import { useRouter } from 'next/navigation';  // Используем useRouter из next/navigation
import React, { useState, useEffect } from 'react';
import { useForm, SubmitHandler } from "react-hook-form";

// Типы данных для формы
type Inputs = {
  from: string;
  to: string;
  class: string;
  departureDate: string;
  arrivalDate: string;
  amount: string;
}

interface BoxMainPageProps {
  className?: string;
  sx?: SxProps;
}

export function BoxMainPage({ className, sx }: BoxMainPageProps) {
  const {
    register,
    handleSubmit,
    formState: { errors },
    setError, // Функция для явного выставления ошибок, если нужно
  } = useForm<Inputs>(); // Инициализация useForm

  const [isClient, setIsClient] = useState(false);  // Состояние для проверки, что мы на клиенте

  const router = useRouter(); // Используем useRouter из next/navigation

  useEffect(() => {
    setIsClient(true);  // Устанавливаем состояние, когда компонент монтируется на клиенте
  }, []);

  // Обработчик отправки формы
  const onSubmit: SubmitHandler<Inputs> = (data) => {
    console.log("Form data: ", data); // Логируем данные формы
    if (isClient && !errors.from) {
      router.push('/tickets'); // Переход на страницу /tickets после успешной валидации
    }
  };

  // Логируем ошибки, чтобы проверить, если форма не отправляется
  console.log(errors);

  return (
    <Box
      component="form" 
      onSubmit={handleSubmit(onSubmit)} // Передаем обработчик на отправку формы
      className={clsx(styles.mainPageBox, className)} 
      noValidate autoComplete="off"
      sx={sx}
    >
      <Grid2 container spacing={2} sx={{ marginTop: "-10px" }}>
        <Grid2>
          {/* Регистрируем поле "Where from?" с валидацией */}
          <Autocompletes 
            label="Where from?" 
            className={styles.inputs}
            {...register("from", { required: "This field is required" })}
          />
          {errors.from && <p>{errors.from.message}</p>}  {/* Показываем ошибку, если поле пустое */}
        </Grid2>
        <Grid2>
          <Autocompletes label="Where to?" className={styles.inputs} />
        </Grid2>

        <Grid2>
          <Selects
            label="Class"
            className="passengers_class"
            menuItems={[
              { value: "Econom", label: "Econom" },
              { value: "Business", label: "Business" },
              { value: "FirstClass", label: "First Class" },
            ]}
            {...register("class")}
          />
        </Grid2>

        <Grid2>
          <DatePickers 
            label="Departure date" 
            className={styles.datePicker}
            {...register("departureDate")}
            sx={{width: { xs: 137, sm: 138, md: 172, lg: 207, xl: 207 }}}
          />
        </Grid2>

        <Grid2>
          <DatePickers 
            label="Arrival date" 
            className={styles.datePicker}
            {...register("arrivalDate")}
            sx={{width: { xs: 137, sm: 138, md: 172, lg: 207, xl: 207 }}}
          />
        </Grid2>

        <Grid2>
          <Selects
            label="Amount"
            className="passengersAmount"
            menuItems={[
              { value: "1", label: "1" },
              { value: "2", label: "2" },
              { value: "3", label: "3" },
              { value: "4", label: "4" },
              { value: "5", label: "5" },
            ]}
            {...register("amount")}
          />
        </Grid2>

        <Grid2>
          <Buttons 
            label="Search" 
            className={styles.searchButton} 
            type="submit"
            sx={{width: { xs: 290, sm: 150, md: 150, lg: 150, xl: 150 }}}
          />
        </Grid2>
      </Grid2>
    </Box>
  );
}
